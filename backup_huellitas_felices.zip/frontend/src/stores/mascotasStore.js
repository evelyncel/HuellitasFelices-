import { defineStore } from 'pinia'
import mascotasService from '@/services/mascotasService'

export const useMascotasStore = defineStore('mascotas', {
  state: () => ({
    mascotas: [],
    perfilActual: null,
    loading: false,
    loadingPerfil: false,
    error: null,
    filtros: {
      tipo: '',
      ciudad: '',
      estado: '',
    },
  }),

  getters: {
    mascotasFiltradas: (state) => {
      return state.mascotas.filter((m) => {
        const coincideTipo = !state.filtros.tipo || m.tipo.toLowerCase() === state.filtros.tipo.toLowerCase()
        const coincideCiudad = !state.filtros.ciudad || m.ciudad?.toLowerCase().includes(state.filtros.ciudad.toLowerCase())
        const coincideEstado = !state.filtros.estado || m.estado === state.filtros.estado
        return coincideTipo && coincideCiudad && coincideEstado
      })
    },
    totalDisponibles: (state) => {
      return state.mascotas.filter((m) => m.estado === 'Disponible').length
    },
  },

  actions: {
    async fetchMascotas() {
      this.loading = true
      this.error = null
      try {
        const data = await mascotasService.getMascotas()
        this.mascotas = data.mascotas || []
      } catch (err) {
        this.error =
          err.response?.data?.error ||
          'No se pudieron cargar las mascotas desde el servidor'
      } finally {
        this.loading = false
      }
    },

    async fetchPerfil(id) {
      this.loadingPerfil = true
      this.perfilActual = null
      try {
        const data = await mascotasService.getMascotaPerfil(id)
        this.perfilActual = data
        return data
      } catch (err) {
        this.error = err.response?.data?.error || 'Error al obtener el perfil de la mascota'
        return null
      } finally {
        this.loadingPerfil = false
      }
    },

    async registrarMascota(mascotaData) {
      try {
        const response = await mascotasService.crearMascota(mascotaData)
        // Refrescar lista de mascotas tras registro exitoso
        await this.fetchMascotas()
        return { success: true, data: response }
      } catch (err) {
        const errorMsg =
          err.response?.data?.error ||
          'Error al registrar la mascota en la base de datos'
        return { success: false, error: errorMsg }
      }
    },

    setFiltroTipo(tipo) {
      this.filtros.tipo = tipo
    },

    setFiltroCiudad(ciudad) {
      this.filtros.ciudad = ciudad
    },

    setFiltroEstado(estado) {
      this.filtros.estado = estado
    },

    limpiarFiltros() {
      this.filtros = {
        tipo: '',
        ciudad: '',
        estado: '',
      }
    },
  },
})
