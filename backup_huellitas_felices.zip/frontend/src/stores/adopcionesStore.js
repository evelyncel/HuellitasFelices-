import { defineStore } from 'pinia'
import adopcionesService from '@/services/adopcionesService'
import { useAuthStore } from './authStore'

export const useAdopcionesStore = defineStore('adopciones', {
  state: () => ({
    solicitudes: [],
    loading: false,
    submitting: false,
    error: null,
    successMessage: null,
  }),

  actions: {
    async fetchSolicitudes() {
      const authStore = useAuthStore()
      this.loading = true
      this.error = null
      try {
        const params = {}
        if (!authStore.isAdmin && authStore.user?.id) {
          params.usuario_id = authStore.user.id
        }
        const data = await adopcionesService.getSolicitudes(params)
        this.solicitudes = data.adopciones || []
      } catch (err) {
        this.error =
          err.response?.data?.error ||
          'Error al cargar las solicitudes de adopción'
      } finally {
        this.loading = false
      }
    },

    async crearSolicitud(solicitudData) {
      this.submitting = true
      this.error = null
      this.successMessage = null
      try {
        const response = await adopcionesService.crearSolicitud(solicitudData)
        this.successMessage = response.mensaje || '¡Solicitud registrada correctamente!'
        // Refrescar solicitudes
        await this.fetchSolicitudes()
        return { success: true, data: response }
      } catch (err) {
        const errorMsg =
          err.response?.data?.error ||
          'No se pudo registrar la solicitud de adopción'
        this.error = errorMsg
        return { success: false, error: errorMsg }
      } finally {
        this.submitting = false
      }
    },

    limpiarMensajes() {
      this.error = null
      this.successMessage = null
    },
  },
})
