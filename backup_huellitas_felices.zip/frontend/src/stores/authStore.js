import { defineStore } from 'pinia'
import authService from '@/services/authService'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: localStorage.getItem('huellitas_token') || null,
    user: JSON.parse(localStorage.getItem('huellitas_user') || 'null'),
    loading: false,
    error: null,
  }),

  getters: {
    isAuthenticated: (state) => Boolean(state.token),
    currentUser: (state) => state.user,
    isAdmin: (state) => state.user?.rol === 'admin',
  },

  actions: {
    async login(usuario, password) {
      this.loading = true
      this.error = null
      try {
        const data = await authService.login(usuario, password)
        this.token = data.token
        this.user = data.usuario

        localStorage.setItem('huellitas_token', data.token)
        localStorage.setItem('huellitas_user', JSON.stringify(data.usuario))

        return { success: true, user: data.usuario }
      } catch (err) {
        const errorMsg =
          err.response?.data?.error ||
          'Error al conectar con el servidor. Verifica que el backend esté activo.'
        this.error = errorMsg
        return { success: false, error: errorMsg }
      } finally {
        this.loading = false
      }
    },

    async register(datosUsuario) {
      this.loading = true
      this.error = null
      try {
        const data = await authService.register(datosUsuario)
        return { success: true, data }
      } catch (err) {
        const errorMsg =
          err.response?.data?.error ||
          'No se pudo completar el registro. Intenta con otro usuario o verifica la conexión.'
        this.error = errorMsg
        return { success: false, error: errorMsg }
      } finally {
        this.loading = false
      }
    },

    async checkAuth() {
      if (!this.token) return false
      try {
        await authService.verificarSesion()
        return true
      } catch (err) {
        this.logout()
        return false
      }
    },

    logout() {
      this.token = null
      this.user = null
      this.error = null
      localStorage.removeItem('huellitas_token')
      localStorage.removeItem('huellitas_user')
    },
  },
})
