<script setup>
import { ref, computed, onMounted } from 'vue'
import { useAuthStore } from '@/stores/authStore'
import { useMascotasStore } from '@/stores/mascotasStore'
import Navbar from '@/components/Navbar.vue'
import PetCard from '@/components/PetCard.vue'
import PetDetailModal from '@/components/PetDetailModal.vue'
import AdoptionModal from '@/components/AdoptionModal.vue'
import CreatePetModal from '@/components/CreatePetModal.vue'
import MyAdoptionsModal from '@/components/MyAdoptionsModal.vue'
import ProfileModal from '@/components/ProfileModal.vue'
import {
  Heart,
  Search,
  Filter,
  Sparkles,
  ShieldCheck,
  Home as HomeIcon,
  CheckCircle,
  FileSearch,
  PhoneCall,
  Smile,
  RefreshCw,
  AlertTriangle,
} from 'lucide-vue-next'

const authStore = useAuthStore()
const mascotasStore = useMascotasStore()

// Estados para modales
const showDetailModal = ref(false)
const showAdoptionModal = ref(false)
const showCreatePetModal = ref(false)
const showMisSolicitudesModal = ref(false)
const showProfileModal = ref(false)

const selectedPet = ref(null)
const searchQuery = ref('')
const selectedCity = ref('')
const selectedType = ref('')
const onlyAvailable = ref(true)

onMounted(async () => {
  await mascotasStore.fetchMascotas()
})

// Mascotas filtradas localmente con barra de búsqueda
const listaMascotas = computed(() => {
  return mascotasStore.mascotas.filter((pet) => {
    // Filtro por búsqueda de nombre o raza
    const matchesSearch =
      !searchQuery.value ||
      pet.nombre?.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
      pet.raza?.toLowerCase().includes(searchQuery.value.toLowerCase())

    // Filtro por especie
    const matchesType =
      !selectedType.value ||
      pet.tipo?.toLowerCase() === selectedType.value.toLowerCase()

    // Filtro por ciudad
    const matchesCity =
      !selectedCity.value ||
      pet.ciudad?.toLowerCase().includes(selectedCity.value.toLowerCase())

    // Filtro por estado
    const matchesStatus =
      !onlyAvailable.value ||
      pet.estado?.toLowerCase() === 'disponible'

    return matchesSearch && matchesType && matchesCity && matchesStatus
  })
})

// Acciones de modales
async function handleVerDetalle(mascota) {
  selectedPet.value = mascota
  showDetailModal.value = true
  // Cargar perfil completo con refugio
  await mascotasStore.fetchPerfil(mascota.id)
}

function handleIniciarAdopcion(mascota) {
  selectedPet.value = mascota
  showDetailModal.value = false
  showAdoptionModal.value = true
}

function handleAdopcionCompletada() {
  // Refrescar mascotas tras solicitud
  mascotasStore.fetchMascotas()
}

function handleMascotaCreada() {
  mascotasStore.fetchMascotas()
}
</script>

<template>
  <div class="home-page">
    <!-- Barra de Navegación -->
    <Navbar
      @openMisSolicitudes="showMisSolicitudesModal = true"
      @openMiPerfil="showProfileModal = true"
      @openRegistrarMascota="showCreatePetModal = true"
    />

    <!-- Sección de Bienvenida (Hero Banner) -->
    <section id="inicio" class="hero-section">
      <div class="hero-container">
        <div class="hero-content">
          <div class="hero-badge">
            <Sparkles :size="16" class="sparkle-icon" />
            <span>Adopta con responsabilidad y amor</span>
          </div>
          <h1 class="hero-title">
            Encuentra a tu nuevo <span class="highlight-text">mejor amigo</span>
          </h1>
          <p class="hero-description">
            Bríndales una segunda oportunidad. En Huellitas Felices conectamos corazones con mascotas rescatadas que sueñan con un hogar lleno de cariño, protección y cuidados.
          </p>
          <div class="hero-actions">
            <a href="#mascotas" class="btn btn-primary btn-lg">
              <Heart :size="18" />
              <span>Conocer Mascotas</span>
            </a>
            <a href="#proceso" class="btn btn-outline btn-lg">
              <span>¿Cómo funciona?</span>
            </a>
          </div>

          <!-- Métricas de Confianza -->
          <div class="hero-stats">
            <div class="stat-box">
              <span class="stat-number">{{ mascotasStore.totalDisponibles }}</span>
              <span class="stat-label">Disponibles ahora</span>
            </div>
            <div class="stat-divider"></div>
            <div class="stat-box">
              <span class="stat-number">100%</span>
              <span class="stat-label">Atención veterinaria</span>
            </div>
            <div class="stat-divider"></div>
            <div class="stat-box">
              <span class="stat-number">3+</span>
              <span class="stat-label">Refugios aliados</span>
            </div>
          </div>
        </div>

        <div class="hero-image-wrapper">
          <div class="hero-image-backdrop"></div>
          <img
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSS_6ZM0QlKnptxYlRw9TnsvWtD2LklFUxxEWaShZu05wtOXx0LqAtgIPg&s=10"
            alt="Perro alegre y saludable"
            class="hero-img"
          />
          <div class="floating-hero-card">
            <div class="float-icon">
              <Heart :size="20" />
            </div>
            <div>
              <p class="float-title">Adopción Responsable</p>
              <p class="float-sub">Salud y vacunación al día</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Catálogo de Mascotas (Sección Principal) -->
    <section id="mascotas" class="catalog-section">
      <div class="section-container">
        <div class="catalog-header">
          <div>
            <span class="section-tag">Nuestras Mascotas</span>
            <h2 class="section-heading">Peluditos esperando por ti</h2>
            <p class="section-sub">
              Explora las mascotas rescatadas disponibles directamente desde nuestra base de datos.
            </p>
          </div>

          <button
            class="btn btn-secondary"
            @click="showCreatePetModal = true"
            title="Registrar una nueva mascota"
          >
            + Registrar Mascota
          </button>
        </div>

        <!-- Barra de Filtros y Búsqueda -->
        <div class="filters-bar">
          <div class="search-input-wrap">
            <Search :size="18" class="search-icon" />
            <input
              type="text"
              v-model="searchQuery"
              placeholder="Buscar por nombre o raza..."
              class="search-input"
            />
          </div>

          <div class="filter-controls">
            <!-- Filtro de Especie -->
            <div class="pill-group">
              <button
                class="filter-pill"
                :class="{ active: selectedType === '' }"
                @click="selectedType = ''"
              >
                Todos
              </button>
              <button
                class="filter-pill"
                :class="{ active: selectedType === 'Perro' }"
                @click="selectedType = 'Perro'"
              >
                🐶 Perros
              </button>
              <button
                class="filter-pill"
                :class="{ active: selectedType === 'Gato' }"
                @click="selectedType = 'Gato'"
              >
                🐱 Gatos
              </button>
            </div>

            <!-- Filtro de Ciudad -->
            <select v-model="selectedCity" class="select-filter">
              <option value="">Todas las ciudades</option>
              <option value="Popayan">Popayán</option>
              <option value="Cali">Cali</option>
              <option value="Bogota">Bogotá</option>
            </select>

            <!-- Toggle Solo Disponibles -->
            <label class="toggle-label">
              <input type="checkbox" v-model="onlyAvailable" class="toggle-chk" />
              <span>Solo disponibles</span>
            </label>
          </div>
        </div>

        <!-- Estado de Carga -->
        <div v-if="mascotasStore.loading" class="state-container">
          <RefreshCw :size="32" class="spin-animation" />
          <p>Consultando el catálogo en MySQL...</p>
        </div>

        <!-- Error al Cargar -->
        <div v-else-if="mascotasStore.error" class="state-container error-state">
          <AlertTriangle :size="36" />
          <p>{{ mascotasStore.error }}</p>
          <button class="btn btn-outline btn-sm" @click="mascotasStore.fetchMascotas">
            Reintentar
          </button>
        </div>

        <!-- Sin Resultados -->
        <div v-else-if="listaMascotas.length === 0" class="state-container empty-catalog">
          <Heart :size="40" class="muted-heart" />
          <h3>No se encontraron mascotas</h3>
          <p>Prueba ajustando los filtros de búsqueda o la ciudad seleccionada.</p>
          <button
            class="btn btn-outline btn-sm"
            @click="searchQuery = ''; selectedType = ''; selectedCity = ''; onlyAvailable = false"
          >
            Limpiar filtros
          </button>
        </div>

        <!-- Grilla de Tarjetas de Mascotas -->
        <div v-else class="pets-grid">
          <PetCard
            v-for="pet in listaMascotas"
            :key="pet.id"
            :mascota="pet"
            @verDetalle="handleVerDetalle"
            @iniciarAdopcion="handleIniciarAdopcion"
          />
        </div>
      </div>
    </section>

    <!-- Sección Informativa: Proceso de Adopción -->
    <section id="proceso" class="process-section">
      <div class="section-container">
        <div class="process-header">
          <span class="section-tag">Paso a Paso</span>
          <h2 class="section-heading">¿Cómo funciona el proceso de adopción?</h2>
          <p class="section-sub">
            Garantizamos adopciones transparentes, seguras y amorosas en 4 sencillos pasos.
          </p>
        </div>

        <div class="steps-grid">
          <div class="step-card">
            <div class="step-number">1</div>
            <div class="step-icon">
              <Heart :size="24" />
            </div>
            <h3 class="step-title">Encuentra a tu mascota</h3>
            <p class="step-desc">
              Explora las características, fotos y temperamento de los perros y gatos en nuestro catálogo interactivo.
            </p>
          </div>

          <div class="step-card">
            <div class="step-number">2</div>
            <div class="step-icon">
              <FileSearch :size="24" />
            </div>
            <h3 class="step-title">Envía tu solicitud</h3>
            <p class="step-desc">
              Presiona "Adoptar" y completa el formulario con tus condiciones de vivienda y experiencia previa.
            </p>
          </div>

          <div class="step-card">
            <div class="step-number">3</div>
            <div class="step-icon">
              <PhoneCall :size="24" />
            </div>
            <h3 class="step-title">Entrevista con el refugio</h3>
            <p class="step-desc">
              El refugio aliado revisa tu solicitud y programa una entrevista virtual o presencial para conocer a la familia.
            </p>
          </div>

          <div class="step-card">
            <div class="step-number">4</div>
            <div class="step-icon">
              <HomeIcon :size="24" />
            </div>
            <h3 class="step-title">¡Bienvenido a casa!</h3>
            <p class="step-desc">
              Una vez aprobada la adopción, recibes a tu nueva mascota con su historial médico y seguimiento veterinario.
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
      <div class="section-container footer-container">
        <div class="footer-brand">
          <div class="brand-badge-footer">
            <Heart :size="20" />
            <span>Huellitas Felices</span>
          </div>
          <p class="footer-slogan">
            Plataforma web para la adopción y el bienestar animal. Conectando hogares con amor incondicional.
          </p>
        </div>
        <div class="footer-links">
          <span>Backend: Flask en puerto 5000</span> &bull;
          <span>Frontend: Vue.js + Vite en puerto 5174</span> &bull;
          <span>Base de datos: MySQL huellitas_felices</span>
        </div>
      </div>
    </footer>

    <!-- Modales -->
    <PetDetailModal
      v-if="showDetailModal && (mascotasStore.perfilActual || selectedPet)"
      :perfilData="mascotasStore.perfilActual || { mascota: selectedPet }"
      @close="showDetailModal = false"
      @iniciarAdopcion="handleIniciarAdopcion"
    />

    <AdoptionModal
      v-if="showAdoptionModal && selectedPet"
      :mascota="selectedPet"
      @close="showAdoptionModal = false"
      @adopcionCompletada="handleAdopcionCompletada"
    />

    <CreatePetModal
      v-if="showCreatePetModal"
      @close="showCreatePetModal = false"
      @mascotaCreada="handleMascotaCreada"
    />

    <MyAdoptionsModal
      v-if="showMisSolicitudesModal"
      @close="showMisSolicitudesModal = false"
    />

    <ProfileModal
      v-if="showProfileModal"
      @close="showProfileModal = false"
    />
  </div>
</template>

<style scoped>
.home-page {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.section-container {
  max-width: 1240px;
  margin: 0 auto;
  padding: 0 1.5rem;
}

/* Hero Section */
.hero-section {
  padding: 4.5rem 0 3.5rem;
  background: radial-gradient(circle at 85% 20%, #fef4eb 0%, var(--color-cream) 70%);
  overflow: hidden;
}

.hero-container {
  max-width: 1240px;
  margin: 0 auto;
  padding: 0 1.5rem;
  display: grid;
  grid-template-columns: 1.15fr 0.9fr;
  align-items: center;
  gap: 3.5rem;
}

.hero-content {
  display: flex;
  flex-direction: column;
  gap: 1.4rem;
}

.hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  background-color: var(--color-primary-light);
  color: var(--color-primary);
  padding: 0.4rem 0.95rem;
  border-radius: var(--radius-full);
  font-size: 0.85rem;
  font-weight: 700;
  width: fit-content;
}

.sparkle-icon {
  color: var(--color-primary);
}

.hero-title {
  font-size: 3.2rem;
  font-weight: 800;
  color: var(--color-text);
  letter-spacing: -1px;
  line-height: 1.15;
}

.highlight-text {
  color: var(--color-primary);
  position: relative;
  display: inline-block;
}

.hero-description {
  font-size: 1.12rem;
  color: var(--color-text-muted);
  line-height: 1.6;
  max-width: 540px;
}

.hero-actions {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-top: 0.4rem;
}

.btn-lg {
  padding: 0.9rem 1.8rem;
  font-size: 1.02rem;
}

.hero-stats {
  display: flex;
  align-items: center;
  gap: 1.8rem;
  margin-top: 1.5rem;
  padding-top: 1.5rem;
  border-top: 1px solid var(--color-border);
}

.stat-box {
  display: flex;
  flex-direction: column;
}

.stat-number {
  font-family: var(--font-display);
  font-size: 1.8rem;
  font-weight: 800;
  color: var(--color-text);
  line-height: 1;
}

.stat-label {
  font-size: 0.82rem;
  color: var(--color-text-muted);
  font-weight: 600;
  margin-top: 0.2rem;
}

.stat-divider {
  width: 1px;
  height: 38px;
  background-color: var(--color-border);
}

.hero-image-wrapper {
  position: relative;
  display: flex;
  justify-content: center;
}

.hero-image-backdrop {
  position: absolute;
  inset: -15px;
  border-radius: var(--radius-xl);
  background: linear-gradient(135deg, #f4a261 0%, #e07a5f 100%);
  transform: rotate(3deg);
  opacity: 0.25;
  filter: blur(10px);
}

.hero-img {
  position: relative;
  width: 100%;
  max-width: 440px;
  height: 440px;
  object-fit: cover;
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-lg);
  border: 4px solid #ffffff;
}

.floating-hero-card {
  position: absolute;
  bottom: 25px;
  left: -20px;
  background: rgba(255, 255, 255, 0.96);
  backdrop-filter: blur(8px);
  padding: 0.85rem 1.25rem;
  border-radius: var(--radius-lg);
  display: flex;
  align-items: center;
  gap: 0.85rem;
  box-shadow: var(--shadow-md);
  border: 1px solid var(--color-border);
  animation: floatCard 4s ease-in-out infinite alternate;
}

@keyframes floatCard {
  from { transform: translateY(0); }
  to { transform: translateY(-8px); }
}

.float-icon {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: var(--color-primary-light);
  color: var(--color-primary);
  display: flex;
  align-items: center;
  justify-content: center;
}

.float-title {
  font-size: 0.9rem;
  font-weight: 700;
  color: var(--color-text);
}

.float-sub {
  font-size: 0.78rem;
  color: var(--color-text-muted);
}

/* Catálogo */
.catalog-section {
  padding: 5rem 0;
  background-color: #ffffff;
}

.catalog-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  margin-bottom: 2.2rem;
  gap: 1.5rem;
  flex-wrap: wrap;
}

.section-tag {
  font-size: 0.82rem;
  font-weight: 700;
  text-transform: uppercase;
  color: var(--color-secondary);
  letter-spacing: 0.8px;
}

.section-heading {
  font-size: 2.2rem;
  font-weight: 800;
  color: var(--color-text);
  margin-top: 0.2rem;
  letter-spacing: -0.5px;
}

.section-sub {
  font-size: 1rem;
  color: var(--color-text-muted);
  margin-top: 0.4rem;
}

.filters-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  background-color: var(--color-cream);
  padding: 0.85rem 1.25rem;
  border-radius: var(--radius-lg);
  border: 1px solid var(--color-border);
  margin-bottom: 2.5rem;
  flex-wrap: wrap;
}

.search-input-wrap {
  position: relative;
  display: flex;
  align-items: center;
  flex: 1;
  min-width: 250px;
}

.search-icon {
  position: absolute;
  left: 14px;
  color: var(--color-text-muted);
}

.search-input {
  width: 100%;
  padding: 0.65rem 1rem 0.65rem 2.6rem;
  border-radius: var(--radius-full);
  border: 1px solid var(--color-border);
  background-color: #ffffff;
  outline: none;
  font-size: 0.9rem;
}

.search-input:focus {
  border-color: var(--color-primary);
}

.filter-controls {
  display: flex;
  align-items: center;
  gap: 1rem;
  flex-wrap: wrap;
}

.pill-group {
  display: flex;
  gap: 0.35rem;
  background-color: #ffffff;
  padding: 0.25rem;
  border-radius: var(--radius-full);
  border: 1px solid var(--color-border);
}

.filter-pill {
  padding: 0.4rem 0.85rem;
  border-radius: var(--radius-full);
  font-size: 0.82rem;
  font-weight: 600;
  color: var(--color-text-muted);
  cursor: pointer;
  transition: all var(--transition-fast);
}

.filter-pill.active {
  background-color: var(--color-primary);
  color: #ffffff;
}

.select-filter {
  padding: 0.55rem 0.9rem;
  border-radius: var(--radius-full);
  border: 1px solid var(--color-border);
  background-color: #ffffff;
  font-size: 0.85rem;
  color: var(--color-text);
  outline: none;
}

.toggle-label {
  display: flex;
  align-items: center;
  gap: 0.45rem;
  font-size: 0.85rem;
  font-weight: 600;
  color: var(--color-text);
  cursor: pointer;
}

.toggle-chk {
  accent-color: var(--color-primary);
  width: 16px;
  height: 16px;
}

.pets-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(330px, 1fr));
  gap: 2rem;
}

.state-container {
  text-align: center;
  padding: 4.5rem 1rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
  color: var(--color-text-muted);
}

.spin-animation {
  animation: spin 1s linear infinite;
  color: var(--color-primary);
}

.error-state {
  color: #b91c1c;
}

.empty-catalog {
  background: var(--color-cream);
  border-radius: var(--radius-lg);
  border: 1px dashed var(--color-border);
}

.muted-heart {
  color: var(--color-border);
}

/* Proceso */
.process-section {
  padding: 5rem 0;
  background-color: var(--color-cream);
}

.process-header {
  text-align: center;
  margin-bottom: 3.5rem;
}

.steps-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 1.5rem;
}

.step-card {
  background-color: #ffffff;
  padding: 2rem 1.5rem;
  border-radius: var(--radius-xl);
  border: 1px solid var(--color-border);
  box-shadow: var(--shadow-sm);
  display: flex;
  flex-direction: column;
  gap: 0.85rem;
  position: relative;
  transition: all var(--transition-normal);
}

.step-card:hover {
  transform: translateY(-5px);
  box-shadow: var(--shadow-md);
  border-color: rgba(78, 135, 82, 0.4);
}

.step-number {
  position: absolute;
  top: 16px;
  right: 20px;
  font-family: var(--font-display);
  font-size: 2.2rem;
  font-weight: 800;
  color: var(--color-border);
  line-height: 1;
}

.step-icon {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  background-color: var(--color-secondary-light);
  color: var(--color-secondary);
  display: flex;
  align-items: center;
  justify-content: center;
}

.step-title {
  font-size: 1.18rem;
  font-weight: 700;
  color: var(--color-text);
}

.step-desc {
  font-size: 0.88rem;
  color: var(--color-text-muted);
  line-height: 1.55;
}

/* Footer */
.footer {
  margin-top: auto;
  background-color: #222533;
  color: #ffffff;
  padding: 3rem 0;
}

.footer-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 1.25rem;
}

.brand-badge-footer {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  color: #f4a261;
  font-family: var(--font-display);
  font-size: 1.3rem;
  font-weight: 800;
}

.footer-slogan {
  font-size: 0.92rem;
  color: #9ca3af;
  max-width: 500px;
}

.footer-links {
  font-size: 0.82rem;
  color: #6b7280;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  padding-top: 1rem;
  width: 100%;
}

@media (max-width: 992px) {
  .hero-container {
    grid-template-columns: 1fr;
    text-align: center;
  }

  .hero-content {
    align-items: center;
  }

  .hero-actions {
    justify-content: center;
  }

  .hero-stats {
    justify-content: center;
  }

  .floating-hero-card {
    left: 20px;
  }

  .steps-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 600px) {
  .hero-title {
    font-size: 2.3rem;
  }

  .steps-grid {
    grid-template-columns: 1fr;
  }

  .pets-grid {
    grid-template-columns: 1fr;
  }

  .hero-img {
    height: 320px;
  }
}
</style>
