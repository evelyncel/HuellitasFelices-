<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/authStore'
import {
  Heart,
  User,
  Lock,
  Mail,
  MapPin,
  Eye,
  EyeOff,
  AlertCircle,
  ArrowLeft,
  CheckCircle,
  Sparkles,
} from 'lucide-vue-next'

const router = useRouter()
const authStore = useAuthStore()

const form = reactive({
  nombre: '',
  usuario: '',
  correo: '',
  ciudad: 'Popayán',
  password: '',
  confirmPassword: '',
})

const showPassword = ref(false)
const showConfirm = ref(false)
const localError = ref(null)
const success = ref(false)
const loading = ref(false)

function goHome() {
  router.push({ name: 'Landing' })
}

function validate() {
  if (!form.nombre.trim()) return 'Por favor ingresa tu nombre completo.'
  if (!form.usuario.trim()) return 'Por favor elige un nombre de usuario.'
  if (!form.correo.trim() || !form.correo.includes('@'))
    return 'Por favor ingresa un correo electrónico válido.'
  if (!form.ciudad.trim()) return 'Por favor selecciona o escribe tu ciudad.'
  if (form.password.length < 6)
    return 'La contraseña debe tener un mínimo de 6 caracteres.'
  if (form.password !== form.confirmPassword)
    return 'Las contraseñas no coinciden. Por favor verifícalas.'
  return null
}

async function handleRegister() {
  localError.value = null
  const err = validate()
  if (err) {
    localError.value = err
    return
  }

  loading.value = true
  try {
    const payload = {
      nombre: form.nombre.trim(),
      usuario: form.usuario.trim(),
      correo: form.correo.trim(),
      ciudad: form.ciudad.trim(),
      password: form.password,
    }

    const result = await authStore.register(payload)

    if (result && result.success) {
      success.value = true
      try {
        const loginRes = await authStore.login(form.usuario.trim(), form.password)
        if (loginRes.success) {
          setTimeout(() => router.push({ name: 'Home' }), 2000)
          return
        }
      } catch (loginErr) {
        // Fallback
      }
      setTimeout(() => router.push({ name: 'Login' }), 2200)
    } else {
      localError.value =
        result?.error ||
        authStore.error ||
        'No se pudo completar el registro. Intenta nuevamente.'
    }
  } catch (e) {
    localError.value =
      e?.response?.data?.error ||
      'Ocurrió un inconveniente al conectar con el servidor. Intenta de nuevo.'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="register-page">
    <div class="register-card-wrapper">
      <!-- Columna Visual Izquierda (tonos suaves y serenos, idénticos al Home) -->
      <aside class="register-visual-panel">
        <div class="visual-overlay"></div>
        <img
          src="https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&w=1200&q=85"
          alt="Perro y gato descansando juntos en un ambiente cálido"
          class="visual-bg"
        />

        <div class="visual-content">
          <!-- Botón Volver al Home -->
          <button class="back-pill-btn" @click="goHome" title="Volver al inicio">
            <ArrowLeft :size="16" />
            <span>Volver al Home</span>
          </button>

          <!-- Cita inspiradora de adopción renovada -->
          <div class="quote-card">
            <div class="quote-badge">
              <Sparkles :size="15" />
              <span>Un nuevo comienzo</span>
            </div>
            <p class="quote-phrase">
              «No puedes cambiar el pasado de una mascota rescatada, pero puedes reescribir su futuro con amor.»
            </p>
            <span class="quote-sub">Huellitas Felices · Adopción Responsable</span>
          </div>

          <!-- Puntos visuales estéticos -->
          <div class="visual-footer-pills">
            <span class="pill-chip">🐶 Perros & 🐱 Gatos</span>
            <span class="pill-chip">🐾 Adopta con el corazón</span>
          </div>
        </div>
      </aside>

      <!-- Columna Derecha: Formulario de Registro con paleta suave -->
      <section class="register-form-panel">
        <div class="form-container">
          <header class="form-header">
            <div class="header-icon-circle">
              <Heart :size="22" />
            </div>
            <h1 class="register-title">Crear una cuenta</h1>
            <p class="register-subtitle">
              Únete a nuestra comunidad y da el primer paso para brindar un hogar lleno de amor.
            </p>
          </header>

          <!-- Mensaje de éxito -->
          <div v-if="success" class="state-banner success-state">
            <CheckCircle :size="32" class="success-icon" />
            <div>
              <h3 class="state-title">¡Registro completado con éxito!</h3>
              <p class="state-msg">
                Bienvenido a Huellitas Felices. Te estamos redirigiendo a la plataforma...
              </p>
            </div>
          </div>

          <template v-else>
            <!-- Banner de error -->
            <div v-if="localError || authStore.error" class="state-banner error-state">
              <AlertCircle :size="20" class="error-icon" />
              <span>{{ localError || authStore.error }}</span>
            </div>

            <!-- Formulario -->
            <form @submit.prevent="handleRegister" class="register-form" novalidate>
              <!-- Nombre completo -->
              <div class="input-field-group">
                <label class="field-label" for="reg-nombre">Nombre completo</label>
                <div class="input-inner-wrap">
                  <User :size="18" class="input-icon" />
                  <input
                    id="reg-nombre"
                    type="text"
                    v-model="form.nombre"
                    placeholder="Ej: Camila Campo"
                    class="custom-input"
                    autocomplete="name"
                    required
                  />
                </div>
              </div>

              <!-- Usuario y Ciudad en 2 columnas -->
              <div class="two-columns">
                <div class="input-field-group">
                  <label class="field-label" for="reg-usuario">Usuario</label>
                  <div class="input-inner-wrap">
                    <span class="input-icon input-at">@</span>
                    <input
                      id="reg-usuario"
                      type="text"
                      v-model="form.usuario"
                      placeholder="Ej: camila24"
                      class="custom-input"
                      autocomplete="username"
                      required
                    />
                  </div>
                </div>

                <div class="input-field-group">
                  <label class="field-label" for="reg-ciudad">Ciudad</label>
                  <div class="input-inner-wrap">
                    <MapPin :size="18" class="input-icon" />
                    <select id="reg-ciudad" v-model="form.ciudad" class="custom-input custom-select">
                      <option value="Popayán">Popayán</option>
                      <option value="Cali">Cali</option>
                      <option value="Bogotá">Bogotá</option>
                      <option value="Medellín">Medellín</option>
                      <option value="Otra">Otra ciudad</option>
                    </select>
                  </div>
                </div>
              </div>

              <!-- Correo electrónico -->
              <div class="input-field-group">
                <label class="field-label" for="reg-correo">Correo electrónico</label>
                <div class="input-inner-wrap">
                  <Mail :size="18" class="input-icon" />
                  <input
                    id="reg-correo"
                    type="email"
                    v-model="form.correo"
                    placeholder="tucorreo@ejemplo.com"
                    class="custom-input"
                    autocomplete="email"
                    required
                  />
                </div>
              </div>

              <!-- Contraseña -->
              <div class="input-field-group">
                <label class="field-label" for="reg-password">Contraseña</label>
                <div class="input-inner-wrap">
                  <Lock :size="18" class="input-icon" />
                  <input
                    id="reg-password"
                    :type="showPassword ? 'text' : 'password'"
                    v-model="form.password"
                    placeholder="Mínimo 6 caracteres"
                    class="custom-input"
                    autocomplete="new-password"
                    required
                  />
                  <button
                    type="button"
                    class="eye-btn"
                    @click="showPassword = !showPassword"
                    :title="showPassword ? 'Ocultar contraseña' : 'Ver contraseña'"
                  >
                    <Eye v-if="!showPassword" :size="18" />
                    <EyeOff v-else :size="18" />
                  </button>
                </div>
              </div>

              <!-- Confirmar contraseña -->
              <div class="input-field-group">
                <label class="field-label" for="reg-confirm">Confirmar contraseña</label>
                <div class="input-inner-wrap">
                  <Lock :size="18" class="input-icon" />
                  <input
                    id="reg-confirm"
                    :type="showConfirm ? 'text' : 'password'"
                    v-model="form.confirmPassword"
                    placeholder="Repite tu contraseña"
                    class="custom-input"
                    autocomplete="new-password"
                    required
                  />
                  <button
                    type="button"
                    class="eye-btn"
                    @click="showConfirm = !showConfirm"
                    :title="showConfirm ? 'Ocultar contraseña' : 'Ver contraseña'"
                  >
                    <Eye v-if="!showConfirm" :size="18" />
                    <EyeOff v-else :size="18" />
                  </button>
                </div>
              </div>

              <!-- Botón principal en armonía con el botón del Home -->
              <button
                type="submit"
                class="btn-register-submit"
                :disabled="loading"
              >
                <span v-if="!loading">Registrarme y brindar un hogar</span>
                <span v-else>Creando tu cuenta...</span>
              </button>
            </form>

            <!-- Enlace para usuarios ya registrados -->
            <footer class="form-bottom-link">
              <span>¿Ya tienes una cuenta registrada?</span>
              <button type="button" class="login-redirect-btn" @click="router.push({ name: 'Login' })">
                Inicia sesión aquí
              </button>
            </footer>
          </template>
        </div>
      </section>
    </div>
  </div>
</template>

<style scoped>
/* ─────────────────────────────────────────────────────────────
   PÁGINA DE REGISTRO
   - Comparte exactamente el mismo fondo crema (#FAF7F2) y tonos suaves
   - Menos saturada ("menos viva"), elegante y serena
───────────────────────────────────────────────────────────── */
.register-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #FAF7F2;
  padding: 2.5rem 1.5rem;
  box-sizing: border-box;
  font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
  color: #2D3142;
}

.register-card-wrapper {
  display: grid;
  grid-template-columns: 1fr 1.15fr;
  width: 100%;
  max-width: 1040px;
  min-height: 620px;
  background-color: #FAF7F2;
  border-radius: 28px;
  overflow: hidden;
  box-shadow: 0 16px 45px -10px rgba(45, 49, 66, 0.08);
  border: 1px solid #E8E1D5;
}

/* ─────────────────────────────────────────────────────────────
   PANEL VISUAL IZQUIERDO (TONOS CALMOS Y CÁLIDOS)
───────────────────────────────────────────────────────────── */
.register-visual-panel {
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 2.6rem 2.2rem;
  overflow: hidden;
  background-color: #D6CEBF;
}

.visual-bg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  filter: brightness(0.92) contrast(0.95);
  transition: transform 1.2s ease;
}

.register-card-wrapper:hover .visual-bg {
  transform: scale(1.02);
}

/* Filtro cálido suave y desaturado para que no contraste bruscamente */
.visual-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(
    145deg,
    rgba(45, 49, 66, 0.48) 0%,
    rgba(186, 151, 133, 0.45) 100%
  );
  backdrop-filter: blur(2px);
  z-index: 1;
}

.visual-content {
  position: relative;
  z-index: 2;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%;
  gap: 2rem;
}

.back-pill-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  background: rgba(255, 255, 255, 0.22);
  backdrop-filter: blur(8px);
  padding: 0.5rem 1.1rem;
  border-radius: 9999px;
  color: #FFFFFF;
  font-size: 0.85rem;
  font-weight: 600;
  border: 1px solid rgba(255, 255, 255, 0.35);
  cursor: pointer;
  width: fit-content;
  transition: all 0.2s ease;
}

.back-pill-btn:hover {
  background: rgba(255, 255, 255, 0.36);
  transform: translateX(-3px);
}

.quote-card {
  background: rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(14px);
  padding: 1.8rem;
  border-radius: 20px;
  border: 1px solid rgba(255, 255, 255, 0.32);
  color: #FFFFFF;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.quote-badge {
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  font-size: 0.76rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  color: #F8E2C8;
}

.quote-phrase {
  font-family: 'Outfit', 'Plus Jakarta Sans', system-ui, sans-serif;
  font-size: 1.18rem;
  font-weight: 600;
  line-height: 1.45;
  margin: 0;
}

.quote-sub {
  font-size: 0.8rem;
  color: rgba(255, 255, 255, 0.85);
  font-weight: 500;
}

.visual-footer-pills {
  display: flex;
  gap: 0.6rem;
  flex-wrap: wrap;
}

.pill-chip {
  padding: 0.4rem 0.85rem;
  border-radius: 9999px;
  background: rgba(30, 32, 42, 0.35);
  backdrop-filter: blur(6px);
  color: #FFFFFF;
  font-size: 0.76rem;
  font-weight: 600;
}

/* ─────────────────────────────────────────────────────────────
   PANEL DERECHO: FORMULARIO
───────────────────────────────────────────────────────────── */
.register-form-panel {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2.6rem 2.8rem;
  background-color: #FAF7F2;
}

.form-container {
  width: 100%;
  max-width: 420px;
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}

.form-header {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
}

.header-icon-circle {
  width: 44px;
  height: 44px;
  border-radius: 14px;
  background-color: #F3ECE1;
  color: #E07A5F;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 0.2rem;
}

.register-title {
  font-family: 'Outfit', 'Plus Jakarta Sans', system-ui, sans-serif;
  font-size: 1.85rem;
  font-weight: 800;
  color: #1F2430;
  letter-spacing: -0.6px;
  margin: 0;
}

.register-subtitle {
  font-size: 0.88rem;
  color: #6C757D;
  line-height: 1.45;
  margin: 0;
}

/* Banners de estado */
.state-banner {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  padding: 0.85rem 1rem;
  border-radius: 14px;
  font-size: 0.86rem;
  animation: fadeIn 0.25s ease;
}

.error-state {
  background-color: #FEE2E2;
  border: 1px solid #FECACA;
  color: #B91C1C;
}

.success-state {
  background-color: #ECFDF5;
  border: 1px solid #A7F3D0;
  color: #065F46;
  padding: 1.4rem 1.1rem;
  text-align: left;
}

.state-title {
  font-size: 1.05rem;
  font-weight: 700;
  margin: 0 0 0.25rem;
}

.state-msg {
  font-size: 0.86rem;
  color: #047857;
  margin: 0;
}

/* Formulario */
.register-form {
  display: flex;
  flex-direction: column;
  gap: 0.95rem;
}

.two-columns {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.85rem;
}

.input-field-group {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
}

.field-label {
  font-size: 0.82rem;
  font-weight: 700;
  color: #2D3142;
}

.input-inner-wrap {
  position: relative;
  display: flex;
  align-items: center;
}

.input-icon {
  position: absolute;
  left: 14px;
  color: #8D93A0;
  pointer-events: none;
}

.input-at {
  font-weight: 700;
  font-size: 0.95rem;
  left: 15px;
}

.custom-input {
  width: 100%;
  padding: 0.74rem 2.5rem 0.74rem 2.5rem;
  border-radius: 12px;
  border: 1.5px solid #E4DDD2;
  background-color: #FFFFFF;
  color: #2D3142;
  font-size: 0.9rem;
  outline: none;
  box-sizing: border-box;
  transition: all 0.18s ease;
}

.custom-select {
  cursor: pointer;
  padding-left: 2.5rem;
}

.custom-input:focus {
  border-color: #E07A5F;
  background-color: #FFFFFF;
  box-shadow: 0 0 0 3px rgba(224, 122, 95, 0.12);
}

.eye-btn {
  position: absolute;
  right: 12px;
  background: none;
  border: none;
  color: #8D93A0;
  cursor: pointer;
  padding: 0.2rem;
}

.eye-btn:hover {
  color: #2D3142;
}

/* Botón principal en armonía con el Home */
.btn-register-submit {
  width: 100%;
  padding: 0.95rem 1.6rem;
  border-radius: 9999px;
  background-color: #FF7262;
  color: #FFFFFF;
  font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
  font-size: 0.98rem;
  font-weight: 700;
  border: none;
  outline: none;
  cursor: pointer;
  box-shadow: 0 8px 22px rgba(255, 114, 98, 0.32);
  transition: all 0.22s ease;
  margin-top: 0.3rem;
}

.btn-register-submit:hover:not(:disabled) {
  background-color: #F85F4D;
  transform: translateY(-2px);
  box-shadow: 0 12px 26px rgba(255, 114, 98, 0.42);
}

.btn-register-submit:disabled {
  opacity: 0.65;
  cursor: not-allowed;
}

/* Footer del Formulario */
.form-bottom-link {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.45rem;
  font-size: 0.86rem;
  color: #6C757D;
  padding-top: 0.15rem;
}

.login-redirect-btn {
  background: none;
  border: none;
  color: #E07A5F;
  font-weight: 700;
  cursor: pointer;
  padding: 0;
  font-size: 0.86rem;
}

.login-redirect-btn:hover {
  text-decoration: underline;
}

/* ─────────────────────────────────────────────────────────────
   RESPONSIVE
───────────────────────────────────────────────────────────── */
@media (max-width: 960px) {
  .register-card-wrapper {
    grid-template-columns: 1fr;
    max-width: 520px;
  }

  .register-visual-panel {
    min-height: 220px;
    padding: 1.8rem;
  }

  .quote-phrase {
    font-size: 1.05rem;
  }

  .register-form-panel {
    padding: 2.2rem 1.8rem;
  }
}

@media (max-width: 520px) {
  .register-page {
    padding: 1rem;
  }

  .register-card-wrapper {
    border-radius: 20px;
  }

  .two-columns {
    grid-template-columns: 1fr;
  }

  .register-form-panel {
    padding: 1.8rem 1.2rem;
  }

  .register-title {
    font-size: 1.6rem;
  }
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-4px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
