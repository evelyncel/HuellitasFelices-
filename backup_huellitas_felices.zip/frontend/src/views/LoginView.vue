<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/authStore'
import {
  Heart,
  Lock,
  User,
  Eye,
  EyeOff,
  AlertCircle,
  Sparkles,
  ShieldCheck,
  ArrowRight,
} from 'lucide-vue-next'

const router = useRouter()
const authStore = useAuthStore()

const form = reactive({
  usuario: '',
  password: '',
})

const showPassword = ref(false)
const localValidation = ref(null)
const infoModal = ref(false)

// Cuentas de prueba para agilizar la evaluación
const demoUsers = [
  { usuario: 'carlos', pass: 'adoptante123', label: 'Carlos (Adoptante)' },
  { usuario: 'maria', pass: 'adoptante123', label: 'María (Adoptante)' },
  { usuario: 'admin', pass: 'admin123', label: 'Administrador' },
]

function setDemoUser(user) {
  form.usuario = user.usuario
  form.password = user.pass
  localValidation.value = null
}

async function handleLogin() {
  localValidation.value = null

  if (!form.usuario.trim()) {
    localValidation.value = 'Por favor ingresa tu usuario o correo electrónico.'
    return
  }
  if (!form.password) {
    localValidation.value = 'Por favor ingresa tu contraseña.'
    return
  }

  const result = await authStore.login(form.usuario.trim(), form.password)
  if (result.success) {
    router.push('/app')
  }
}
</script>

<template>
  <div class="login-page">
    <div class="login-card-wrapper">
      <!-- Columna Izquierda: Imagen inspiradora y Cita motivacional -->
      <div class="login-visual-panel">
        <div class="visual-overlay"></div>
        <img
          src="https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&w=1200&q=85"
          alt="Perro y gato felices juntos"
          class="visual-bg-image"
        />

        <div class="visual-content">
          <div class="visual-brand">
            <div class="brand-badge">
              <Heart :size="20" class="heart-pulse" />
              <span>Huellitas Felices</span>
            </div>
          </div>

          <div class="quote-box">
            <span class="quote-mark">“</span>
            <p class="quote-text">
              Adoptar no cambia el mundo entero, pero cambia el mundo de una mascota para siempre.
            </p>
            <div class="quote-footer">
              <Sparkles :size="16" class="sparkle-icon" />
              <span>Por un mundo con más colitas felices</span>
            </div>
          </div>

          <div class="visual-footer-stats">
            <div class="stat-pill">
              <ShieldCheck :size="16" />
              <span>Adopciones 100% Seguras</span>
            </div>
            <div class="stat-pill">
              <Heart :size="16" />
              <span>Refugios Verificados</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Columna Derecha: Formulario de Login -->
      <div class="login-form-panel">
        <div class="form-container">
          <div class="form-header">
            <div class="logo-circle">
              <Heart :size="24" />
            </div>
            <h1 class="login-title">Bienvenido de nuevo</h1>
            <p class="login-sub">
              Ingresa tus credenciales para acceder a la plataforma y gestionar tus adopciones.
            </p>
          </div>

          <!-- Mensajes de Error (Validación o Credenciales inválidas) -->
          <div v-if="localValidation || authStore.error" class="error-banner">
            <AlertCircle :size="18" class="error-icon" />
            <span>{{ localValidation || authStore.error }}</span>
          </div>

          <!-- Formulario Real -->
          <form @submit.prevent="handleLogin" class="auth-form">
            <div class="input-group">
              <label class="input-label" for="usuario">Usuario o Correo Electrónico</label>
              <div class="input-field-wrap">
                <User :size="18" class="field-icon" />
                <input
                  id="usuario"
                  type="text"
                  v-model="form.usuario"
                  placeholder="Ej: carlos o admin"
                  class="text-input"
                  autocomplete="username"
                  required
                />
              </div>
            </div>

            <div class="input-group">
              <label class="input-label" for="password">Contraseña</label>
              <div class="input-field-wrap">
                <Lock :size="18" class="field-icon" />
                <input
                  id="password"
                  :type="showPassword ? 'text' : 'password'"
                  v-model="form.password"
                  placeholder="Tu contraseña secreta"
                  class="text-input"
                  autocomplete="current-password"
                  required
                />
                <button
                  type="button"
                  class="toggle-eye"
                  @click="showPassword = !showPassword"
                  title="Mostrar / ocultar contraseña"
                >
                  <Eye v-if="!showPassword" :size="18" />
                  <EyeOff v-else :size="18" />
                </button>
              </div>
            </div>

            <!-- Botón de Inicio de Sesión -->
            <button
              type="submit"
              class="btn btn-primary submit-btn"
              :disabled="authStore.loading"
            >
              <span v-if="!authStore.loading">Iniciar Sesión</span>
              <span v-else>Verificando credenciales...</span>
              <ArrowRight v-if="!authStore.loading" :size="18" />
            </button>
          </form>

          <!-- Acceso Rápido con Cuentas de Prueba -->
          <div class="demo-section">
            <span class="demo-title">Cuentas de prueba para evaluar:</span>
            <div class="demo-pills">
              <button
                v-for="u in demoUsers"
                :key="u.usuario"
                type="button"
                class="demo-chip"
                @click="setDemoUser(u)"
                title="Hacer clic para autocompletar este usuario"
              >
                {{ u.label }}
              </button>
            </div>
          </div>

          <!-- Enlace de Registro -->
          <div class="form-bottom">
            <span>¿Aún no tienes una cuenta?</span>
            <button type="button" class="link-btn" @click="router.push('/register')">
              Crear una cuenta nueva
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal informativo para Registro de Nuevos Usuarios -->
    <div v-if="infoModal" class="modal-overlay" @click.self="infoModal = false">
      <div class="modal-content modal-register-info">
        <Heart :size="40" class="reg-icon" />
        <h3 class="reg-title">Registro de Nuevos Adoptantes</h3>
        <p class="reg-text">
          ¡Nos alegra tu interés en brindar un hogar a un peludito! El registro público está habilitado para todos los amantes de los animales.
        </p>
        <p class="reg-sub">
          Para pruebas en este entorno académico, puedes ingresar de inmediato con cualquiera de las cuentas activas cargadas en MySQL (<strong>carlos</strong>, <strong>maria</strong>, <strong>juan</strong>, <strong>laura</strong> o <strong>admin</strong>).
        </p>
        <button class="btn btn-primary" @click="infoModal = false">
          Entendido, probar con una cuenta
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1.5rem;
  background: radial-gradient(circle at 10% 20%, #fef8f4 0%, #f4ede2 90%);
}

.login-card-wrapper {
  display: grid;
  grid-template-columns: 1.15fr 1fr;
  width: 100%;
  max-width: 1050px;
  min-height: 620px;
  background-color: var(--color-surface);
  border-radius: var(--radius-xl);
  overflow: hidden;
  box-shadow: 0 25px 60px -15px rgba(45, 49, 66, 0.16);
  border: 1px solid var(--color-border);
}

/* Panel Izquierdo */
.login-visual-panel {
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 3rem 2.5rem;
  overflow: hidden;
  background-color: #2d3142;
}

.visual-bg-image {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 1.2s ease;
}

.login-card-wrapper:hover .visual-bg-image {
  transform: scale(1.03);
}

.visual-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(
    145deg,
    rgba(22, 24, 33, 0.82) 0%,
    rgba(224, 122, 95, 0.7) 100%
  );
  z-index: 1;
}

.visual-content {
  position: relative;
  z-index: 2;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%;
  gap: 2.5rem;
}

.brand-badge {
  display: inline-flex;
  align-items: center;
  gap: 0.6rem;
  background: rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(8px);
  padding: 0.5rem 1.1rem;
  border-radius: var(--radius-full);
  color: #ffffff;
  font-size: 0.95rem;
  font-weight: 700;
  border: 1px solid rgba(255, 255, 255, 0.25);
}

.heart-pulse {
  animation: pulse 1.8s infinite;
}

@keyframes pulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.15); }
}

.quote-box {
  background: rgba(255, 255, 255, 0.18);
  backdrop-filter: blur(12px);
  padding: 2.2rem;
  border-radius: var(--radius-lg);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #ffffff;
  position: relative;
}

.quote-mark {
  font-size: 3.5rem;
  font-family: serif;
  line-height: 0.5;
  display: block;
  opacity: 0.7;
  color: #f4a261;
}

.quote-text {
  font-family: var(--font-display);
  font-size: 1.35rem;
  font-weight: 600;
  line-height: 1.45;
  margin: 0.8rem 0 1.2rem;
  letter-spacing: -0.2px;
}

.quote-footer {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.85rem;
  color: rgba(255, 255, 255, 0.9);
  font-weight: 500;
}

.sparkle-icon {
  color: #f4a261;
}

.visual-footer-stats {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}

.stat-pill {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  background: rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(6px);
  padding: 0.45rem 0.9rem;
  border-radius: var(--radius-full);
  color: #ffffff;
  font-size: 0.8rem;
  font-weight: 600;
}

/* Panel Derecho: Formulario */
.login-form-panel {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 3rem 2.8rem;
  background-color: var(--color-surface);
}

.form-container {
  width: 100%;
  max-width: 380px;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.form-header {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.logo-circle {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  background-color: var(--color-primary-light);
  color: var(--color-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 0.2rem;
}

.login-title {
  font-size: 1.85rem;
  font-weight: 800;
  color: var(--color-text);
  letter-spacing: -0.5px;
}

.login-sub {
  font-size: 0.9rem;
  color: var(--color-text-muted);
  line-height: 1.5;
}

.error-banner {
  display: flex;
  align-items: center;
  gap: 0.65rem;
  padding: 0.85rem 1rem;
  background-color: #fee2e2;
  border: 1px solid #fecaca;
  color: #b91c1c;
  border-radius: var(--radius-md);
  font-size: 0.88rem;
  animation: fadeIn 0.2s ease;
}

.error-icon {
  flex-shrink: 0;
}

.auth-form {
  display: flex;
  flex-direction: column;
  gap: 1.15rem;
}

.input-group {
  display: flex;
  flex-direction: column;
  gap: 0.45rem;
}

.input-label {
  font-size: 0.85rem;
  font-weight: 700;
  color: var(--color-text);
}

.input-field-wrap {
  position: relative;
  display: flex;
  align-items: center;
}

.field-icon {
  position: absolute;
  left: 14px;
  color: var(--color-text-muted);
  pointer-events: none;
}

.text-input {
  width: 100%;
  padding: 0.8rem 2.8rem 0.8rem 2.7rem;
  border-radius: var(--radius-md);
  border: 1.5px solid var(--color-border);
  background-color: var(--color-cream);
  color: var(--color-text);
  font-size: 0.95rem;
  outline: none;
  transition: all var(--transition-fast);
}

.text-input:focus {
  border-color: var(--color-primary);
  background-color: #ffffff;
  box-shadow: 0 0 0 3px rgba(224, 122, 95, 0.15);
}

.toggle-eye {
  position: absolute;
  right: 12px;
  background: none;
  border: none;
  color: var(--color-text-muted);
  padding: 0.3rem;
  cursor: pointer;
}

.submit-btn {
  width: 100%;
  padding: 0.9rem;
  font-size: 1rem;
  margin-top: 0.4rem;
}

.demo-section {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  background: var(--color-beige);
  padding: 0.85rem;
  border-radius: var(--radius-md);
  border: 1px dashed var(--color-border);
}

.demo-title {
  font-size: 0.78rem;
  font-weight: 700;
  color: var(--color-text-muted);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.demo-pills {
  display: flex;
  flex-wrap: wrap;
  gap: 0.4rem;
}

.demo-chip {
  padding: 0.35rem 0.65rem;
  border-radius: var(--radius-sm);
  background: #ffffff;
  border: 1px solid var(--color-border);
  font-size: 0.78rem;
  font-weight: 600;
  color: var(--color-text);
  cursor: pointer;
  transition: all var(--transition-fast);
}

.demo-chip:hover {
  border-color: var(--color-primary);
  color: var(--color-primary);
  background: var(--color-primary-light);
}

.form-bottom {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.4rem;
  font-size: 0.88rem;
  color: var(--color-text-muted);
  padding-top: 0.5rem;
}

.link-btn {
  background: none;
  border: none;
  color: var(--color-primary);
  font-weight: 700;
  cursor: pointer;
}

.link-btn:hover {
  text-decoration: underline;
}

.modal-register-info {
  max-width: 480px;
  padding: 2.2rem;
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
}

.reg-icon {
  color: var(--color-primary);
}

.reg-title {
  font-size: 1.4rem;
  color: var(--color-text);
}

.reg-text {
  font-size: 0.95rem;
  color: var(--color-text);
}

.reg-sub {
  font-size: 0.88rem;
  color: var(--color-text-muted);
  line-height: 1.5;
}

@media (max-width: 900px) {
  .login-card-wrapper {
    grid-template-columns: 1fr;
    max-width: 520px;
  }

  .login-visual-panel {
    min-height: 320px;
    padding: 2rem;
  }

  .quote-text {
    font-size: 1.15rem;
  }

  .login-form-panel {
    padding: 2.5rem 2rem;
  }
}
</style>
