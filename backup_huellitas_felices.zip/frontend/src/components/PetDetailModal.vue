<script setup>
import { computed } from 'vue'
import {
  X,
  Heart,
  MapPin,
  Calendar,
  Building,
  Phone,
  Mail,
  ShieldCheck,
  Activity,
  Smile,
  Zap,
} from 'lucide-vue-next'

const props = defineProps({
  perfilData: {
    type: Object,
    required: true,
  },
})

const emit = defineEmits(['close', 'iniciarAdopcion'])

const mascota = computed(() => props.perfilData.mascota || props.perfilData)
const refugio = computed(() => props.perfilData.refugio || {})

const isDisponible = computed(() => {
  return (mascota.value.estado || '').toLowerCase() === 'disponible'
})

const petPhoto = computed(() => {
  const nombreLower = (mascota.value.nombre || '').toLowerCase()
  const tipoLower = (mascota.value.tipo || '').toLowerCase()

  if (nombreLower.includes('luna')) {
    return 'https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=700&q=80'
  }
  if (nombreLower.includes('max')) {
    return 'https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?auto=format&fit=crop&w=700&q=80'
  }
  if (nombreLower.includes('michi')) {
    return 'https://images.unsplash.com/photo-1533738363-b7f9aef128ce?auto=format&fit=crop&w=700&q=80'
  }
  if (nombreLower.includes('simba')) {
    return 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=700&q=80'
  }
  if (nombreLower.includes('rocky')) {
    return 'https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?auto=format&fit=crop&w=700&q=80'
  }
  if (nombreLower.includes('nala')) {
    return 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=700&q=80'
  }

  if (tipoLower === 'gato') {
    return 'https://images.unsplash.com/photo-1574158622682-e40e69881006?auto=format&fit=crop&w=700&q=80'
  }
  return 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=700&q=80'
})
</script>

<template>
  <div class="modal-overlay" @click.self="emit('close')">
    <div class="modal-content pet-modal">
      <!-- Botón Cerrar -->
      <button class="close-btn" @click="emit('close')" title="Cerrar">
        <X :size="20" />
      </button>

      <!-- Encabezado con Imagen -->
      <div class="modal-header-image">
        <img :src="petPhoto" :alt="mascota.nombre" class="modal-cover-img" />
        <div class="modal-header-overlay">
          <div class="badge-row">
            <span class="status-pill">{{ mascota.estado || 'Disponible' }}</span>
            <span class="type-pill">{{ mascota.tipo }}</span>
          </div>
          <h2 class="pet-title">{{ mascota.nombre }}</h2>
          <p class="pet-subtitle">{{ mascota.raza || 'Criollo' }} &bull; {{ mascota.ciudad }}</p>
        </div>
      </div>

      <!-- Contenido Detallado -->
      <div class="modal-body">
        <!-- Fila de Atributos Clave -->
        <div class="attr-grid">
          <div class="attr-card">
            <span class="attr-label">Edad</span>
            <span class="attr-val">{{ mascota.edad }} {{ mascota.edad === 1 ? 'año' : 'años' }}</span>
          </div>
          <div class="attr-card">
            <span class="attr-label">Sexo</span>
            <span class="attr-val">{{ mascota.sexo || 'N/A' }}</span>
          </div>
          <div class="attr-card">
            <span class="attr-label">Tamaño</span>
            <span class="attr-val">{{ mascota.tamano || 'Mediano' }}</span>
          </div>
          <div class="attr-card">
            <span class="attr-label">Energía</span>
            <span class="attr-val">{{ mascota.nivel_energia || 'Media' }}</span>
          </div>
        </div>

        <!-- Descripción -->
        <div class="section-block">
          <h4 class="section-title">Sobre {{ mascota.nombre }}</h4>
          <p class="section-text">
            {{ mascota.descripcion || 'Esta hermosa mascota busca una familia responsable y amorosa.' }}
          </p>
        </div>

        <!-- Personalidad y Compatibilidad -->
        <div class="section-block">
          <h4 class="section-title">Personalidad y Convivencia</h4>
          <div class="features-list">
            <div class="feature-item">
              <Smile :size="18" class="feat-icon" />
              <span>Personalidad: <strong>{{ mascota.personalidad || 'Cariñoso y sociable' }}</strong></span>
            </div>
            <div class="feature-item">
              <ShieldCheck :size="18" class="feat-icon" />
              <span>Compatible con niños: <strong>{{ mascota.compatible_ninos ? 'Sí' : 'No reportado' }}</strong></span>
            </div>
            <div class="feature-item">
              <ShieldCheck :size="18" class="feat-icon" />
              <span>Compatible con otras mascotas: <strong>{{ mascota.compatible_mascotas ? 'Sí' : 'No reportado' }}</strong></span>
            </div>
          </div>
        </div>

        <!-- Estado de Salud -->
        <div class="section-block">
          <h4 class="section-title">Estado Veterinario</h4>
          <div class="health-badges">
            <div class="health-chip" :class="{ 'chip-active': mascota.vacunado }">
              <ShieldCheck :size="16" />
              <span>Vacunación al día</span>
            </div>
            <div class="health-chip" :class="{ 'chip-active': mascota.desparasitado }">
              <ShieldCheck :size="16" />
              <span>Desparasitado</span>
            </div>
            <div class="health-chip" :class="{ 'chip-active': mascota.esterilizado }">
              <ShieldCheck :size="16" />
              <span>Esterilizado</span>
            </div>
          </div>
        </div>

        <!-- Información del Refugio -->
        <div class="section-block refuge-block" v-if="refugio.nombre">
          <h4 class="section-title">
            <Building :size="18" class="refuge-icon" />
            <span>Refugio responsable</span>
          </h4>
          <div class="refuge-details">
            <p class="refuge-name"><strong>{{ refugio.nombre }}</strong></p>
            <p v-if="refugio.direccion" class="refuge-meta">
              <MapPin :size="15" /> {{ refugio.direccion }}, {{ refugio.ciudad }}
            </p>
            <p v-if="refugio.telefono" class="refuge-meta">
              <Phone :size="15" /> {{ refugio.telefono }}
            </p>
            <p v-if="refugio.email" class="refuge-meta">
              <Mail :size="15" /> {{ refugio.email }}
            </p>
          </div>
        </div>

        <!-- Acciones Inferiores -->
        <div class="modal-footer">
          <button class="btn btn-outline" @click="emit('close')">
            Cerrar
          </button>
          <button
            v-if="isDisponible"
            class="btn btn-primary btn-adopt"
            @click="emit('iniciarAdopcion', mascota)"
          >
            <Heart :size="18" />
            <span>Iniciar Solicitud de Adopción</span>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pet-modal {
  max-width: 600px;
}

.close-btn {
  position: absolute;
  top: 14px;
  right: 14px;
  z-index: 10;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.9);
  color: var(--color-text);
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
}

.modal-header-image {
  position: relative;
  height: 250px;
  width: 100%;
  background: var(--color-beige);
}

.modal-cover-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.modal-header-overlay {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 1.5rem;
  background: linear-gradient(to top, rgba(20, 20, 28, 0.85) 0%, transparent 100%);
  color: #ffffff;
}

.badge-row {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 0.4rem;
}

.status-pill {
  background-color: #2e7d32;
  color: #ffffff;
  padding: 0.2rem 0.65rem;
  border-radius: var(--radius-full);
  font-size: 0.75rem;
  font-weight: 700;
}

.type-pill {
  background: rgba(255, 255, 255, 0.25);
  backdrop-filter: blur(4px);
  padding: 0.2rem 0.65rem;
  border-radius: var(--radius-full);
  font-size: 0.75rem;
  font-weight: 600;
}

.pet-title {
  color: #ffffff;
  font-size: 1.7rem;
  margin-bottom: 0.2rem;
}

.pet-subtitle {
  color: rgba(255, 255, 255, 0.85);
  font-size: 0.9rem;
}

.modal-body {
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.35rem;
}

.attr-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0.75rem;
}

.attr-card {
  background: var(--color-beige);
  padding: 0.75rem 0.5rem;
  border-radius: var(--radius-md);
  text-align: center;
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}

.attr-label {
  font-size: 0.72rem;
  color: var(--color-text-muted);
  text-transform: uppercase;
  font-weight: 700;
}

.attr-val {
  font-size: 0.92rem;
  font-weight: 700;
  color: var(--color-text);
}

.section-block {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.section-title {
  font-size: 1.05rem;
  font-weight: 700;
  color: var(--color-text);
  display: flex;
  align-items: center;
  gap: 0.45rem;
}

.section-text {
  font-size: 0.92rem;
  color: var(--color-text-muted);
  line-height: 1.6;
}

.features-list {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.feature-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.9rem;
  color: var(--color-text-muted);
}

.feat-icon {
  color: var(--color-primary);
}

.health-badges {
  display: flex;
  flex-wrap: wrap;
  gap: 0.6rem;
}

.health-chip {
  display: flex;
  align-items: center;
  gap: 0.4rem;
  padding: 0.4rem 0.75rem;
  border-radius: var(--radius-full);
  font-size: 0.82rem;
  font-weight: 600;
  background-color: #f3f4f6;
  color: #9ca3af;
}

.chip-active {
  background-color: var(--color-secondary-light);
  color: var(--color-secondary);
}

.refuge-block {
  background-color: var(--color-cream);
  padding: 1rem 1.25rem;
  border-radius: var(--radius-lg);
  border: 1px dashed var(--color-border);
}

.refuge-icon {
  color: var(--color-secondary);
}

.refuge-details {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  margin-top: 0.25rem;
  font-size: 0.88rem;
}

.refuge-meta {
  display: flex;
  align-items: center;
  gap: 0.4rem;
  color: var(--color-text-muted);
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 0.75rem;
  padding-top: 0.5rem;
  border-top: 1px solid var(--color-border);
}

.btn-adopt {
  padding-left: 1.5rem;
  padding-right: 1.5rem;
}

@media (max-width: 600px) {
  .attr-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>
