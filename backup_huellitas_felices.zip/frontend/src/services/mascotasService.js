import api from './api'

export default {
  /**
   * Obtiene la lista de mascotas con filtros opcionales (tipo, ciudad, estado).
   */
  async getMascotas(params = {}) {
    const response = await api.get('/api/mascotas', { params })
    return response.data
  },

  /**
   * Obtiene el perfil completo de una mascota junto con los datos de su refugio.
   */
  async getMascotaPerfil(id) {
    const response = await api.get(`/api/mascotas/${id}/perfil`)
    return response.data
  },

  /**
   * Registra una nueva mascota en la base de datos.
   */
  async crearMascota(mascotaData) {
    const response = await api.post('/api/mascotas', mascotaData)
    return response.data
  },

  /**
   * Obtiene mascotas disponibles filtrando por ciudad.
   */
  async getDisponiblesPorCiudad(ciudad) {
    const response = await api.get('/api/mascotas/disponibles', { params: { ciudad } })
    return response.data
  },

  /**
   * Obtiene estadísticas de mascotas.
   */
  async getEstadisticas() {
    const response = await api.get('/api/mascotas/estadisticas')
    return response.data
  },
}
