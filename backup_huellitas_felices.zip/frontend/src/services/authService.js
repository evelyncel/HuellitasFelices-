import api from './api'

export default {
  /**
   * Inicia sesión con usuario y contraseña.
   */
  async login(usuario, password) {
    const response = await api.post('/auth/login', { usuario, password })
    return response.data
  },

  /**
   * Registra un nuevo usuario adoptante.
   */
  async register(datosUsuario) {
    const response = await api.post('/auth/register', datosUsuario)
    return response.data
  },

  /**
   * Verifica la validez del token actual.
   */
  async verificarSesion() {
    const response = await api.get('/auth/me')
    return response.data
  },
}
