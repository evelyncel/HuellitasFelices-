import api from './api'

export default {
  /**
   * Registra una nueva solicitud de adopción.
   */
  async crearSolicitud(solicitudData) {
    const response = await api.post('/api/adopciones', solicitudData)
    return response.data
  },

  /**
   * Consulta las solicitudes de adopción (opcionalmente por usuario).
   */
  async getSolicitudes(params = {}) {
    const response = await api.get('/api/adopciones', { params })
    return response.data
  },

  /**
   * Consulta las solicitudes pendientes.
   */
  async getPendientes() {
    const response = await api.get('/api/adopciones/pendientes')
    return response.data
  },

  /**
   * Consulta el detalle de una solicitud específica.
   */
  async getAdopcion(id) {
    const response = await api.get(`/api/adopciones/${id}`)
    return response.data
  },

  /**
   * Actualiza el estado de una solicitud de adopción.
   */
  async actualizarEstado(id, estado) {
    const response = await api.patch(`/api/adopciones/${id}/estado`, { estado })
    return response.data
  },
}
