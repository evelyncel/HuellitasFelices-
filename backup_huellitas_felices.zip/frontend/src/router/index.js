import { createRouter, createWebHistory } from 'vue-router'
import LandingView from '@/views/LandingView.vue'
import LoginView from '@/views/LoginView.vue'
import HomeView from '@/views/HomeView.vue'
import RegisterView from '@/views/RegisterView.vue'

const routes = [
  // ── Página pública de inicio (sin autenticación requerida) ──
  {
    path: '/',
    name: 'Landing',
    component: LandingView,
    meta: { public: true },
  },

  // ── Registro de nuevos usuarios (público) ──
  {
    path: '/register',
    name: 'Register',
    component: RegisterView,
    meta: { public: true },
  },

  // ── Login (solo para usuarios no autenticados) ──
  {
    path: '/login',
    name: 'Login',
    component: LoginView,
    meta: { guestOnly: true },
  },

  // ── Plataforma principal (requiere autenticación) ──
  {
    path: '/app',
    name: 'Home',
    component: HomeView,
    meta: { requiresAuth: true },
  },

  // ── Redirigir rutas no reconocidas al Landing ──
  {
    path: '/:pathMatch(.*)*',
    redirect: '/',
  },
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) return savedPosition
    if (to.hash) return { el: to.hash, behavior: 'smooth' }
    return { top: 0 }
  },
})

// Guardia de navegación
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('huellitas_token')
  const isAuthenticated = Boolean(token)

  if (to.meta.requiresAuth && !isAuthenticated) {
    // Ruta protegida sin sesión → ir al login
    next({ name: 'Login' })
  } else if (to.meta.guestOnly && isAuthenticated) {
    // Usuario autenticado intenta ir al login → ir a la app
    next({ name: 'Home' })
  } else {
    next()
  }
})

export default router
