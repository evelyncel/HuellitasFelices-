from datetime import date
from flask import Blueprint, jsonify, request

from microservicios.adopciones import repository
from utils.auth import token_required

adopciones_bp = Blueprint("adopciones", __name__, url_prefix="/api/adopciones")
entrevistas_bp = Blueprint("entrevistas", __name__, url_prefix="/api/entrevistas")


@adopciones_bp.get("")
@token_required
def listar_adopciones():
    """Consulta todas las solicitudes de adopción, con filtro opcional por usuario o estado."""
    usuario_id = request.args.get("usuario_id", type=int)
    estado = request.args.get("estado")

    # Si es adoptante y no especifica usuario, puede ver las suyas
    if not usuario_id and getattr(request, "user", {}).get("rol") != "admin":
        usuario_id = int(request.user.get("sub", 0))

    adoptions = repository.get_all_adoptions(usuario_id=usuario_id, estado=estado)
    return jsonify({
        "total": len(adoptions),
        "adopciones": adoptions,
    })


@adopciones_bp.get("/pendientes")
@token_required
def adopciones_pendientes():
    adoptions = repository.get_pending_adoptions()
    return jsonify({
        "total": len(adoptions),
        "adopciones": adoptions,
    })


@adopciones_bp.get("/<int:adopcion_id>")
@token_required
def adopcion_detalle(adopcion_id):
    adoption = repository.get_adoption_by_id(adopcion_id)
    if not adoption:
        return jsonify({"error": f"No existe la adopción con ID {adopcion_id}"}), 404
    return jsonify(adoption)


@adopciones_bp.post("")
@token_required
def crear_adopcion():
    data = request.get_json(silent=True) or {}

    # Extraer usuario_id si viene en el cuerpo o tomarlo del token JWT
    usuario_id = data.get("usuario_id")
    if not usuario_id and hasattr(request, "user"):
        usuario_id = request.user.get("sub") or request.user.get("id")

    # Extraer responsable si no viene en el cuerpo
    responsable = data.get("responsable")
    if not responsable and hasattr(request, "user"):
        responsable = request.user.get("nombre") or request.user.get("usuario")

    data["usuario_id"] = usuario_id
    data["responsable"] = responsable

    required = [
        "usuario_id",
        "mascota_id",
        "motivo",
        "lugar_mascota",
        "personas_casa",
        "experiencia",
        "responsable",
    ]
    missing = [field for field in required if data.get(field) in (None, "")]
    if missing:
        return jsonify({
            "error": f"Campos obligatorios faltantes: {', '.join(missing)}"
        }), 400

    fecha_solicitud = data.get("fecha_solicitud") or date.today().isoformat()

    try:
        adoption_id = repository.create_adoption(
            int(data["usuario_id"]),
            int(data["mascota_id"]),
            fecha_solicitud,
            data["motivo"],
            data["lugar_mascota"],
            int(data["personas_casa"]),
            bool(data.get("tiene_otras_mascotas", False)),
            data["experiencia"],
            data["responsable"],
        )
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:
        return jsonify({"error": f"Error al crear la solicitud: {str(exc)}"}), 500

    return jsonify({
        "mensaje": "Solicitud de adopción creada correctamente",
        "id": adoption_id,
        "estado": "En revisión",
    }), 201


@adopciones_bp.patch("/<int:adopcion_id>/estado")
@token_required
def actualizar_estado(adopcion_id):
    data = request.get_json(silent=True) or {}
    nuevo_estado = data.get("estado")

    if not nuevo_estado:
        return jsonify({"error": "El campo estado es obligatorio"}), 400

    try:
        updated = repository.update_adoption_status(adopcion_id, nuevo_estado)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    if not updated:
        return jsonify({"error": f"No existe la adopción con ID {adopcion_id}"}), 404

    return jsonify({
        "mensaje": "Estado actualizado correctamente",
        "id": adopcion_id,
        "estado": nuevo_estado,
    })


@adopciones_bp.post("/<int:adopcion_id>/entrevista")
@token_required
def programar_entrevista(adopcion_id):
    data = request.get_json(silent=True) or {}

    fecha = data.get("fecha")
    hora = data.get("hora")
    modalidad = data.get("modalidad")
    observaciones = data.get("observaciones", "")

    if not fecha or not hora or not modalidad:
        return jsonify({
            "error": "Los campos fecha, hora y modalidad son obligatorios"
        }), 400

    interview_id = repository.schedule_interview(
        adopcion_id,
        fecha,
        hora,
        modalidad,
        observaciones,
    )

    if interview_id is None:
        return jsonify({"error": f"No existe la adopción con ID {adopcion_id}"}), 404

    return jsonify({
        "mensaje": "Entrevista programada correctamente",
        "entrevista_id": interview_id,
        "adopcion_id": adopcion_id,
        "fecha": fecha,
        "hora": hora,
        "modalidad": modalidad,
    }), 201


@entrevistas_bp.get("/proximas")
@token_required
def entrevistas_proximas():
    interviews = repository.get_upcoming_interviews()
    return jsonify({
        "total": len(interviews),
        "entrevistas": interviews,
    })
