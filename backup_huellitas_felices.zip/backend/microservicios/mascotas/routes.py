from flask import Blueprint, jsonify, request

from microservicios.mascotas import repository
from utils.auth import token_required

mascotas_bp = Blueprint("mascotas", __name__, url_prefix="/api/mascotas")


@mascotas_bp.get("")
@token_required
def listar_mascotas():
    """Consulta todas las mascotas registradas con filtros opcionales."""
    tipo = request.args.get("tipo")
    ciudad = request.args.get("ciudad")
    estado = request.args.get("estado")

    pets = repository.get_all_pets(pet_type=tipo, city=ciudad, status=estado)
    return jsonify({
        "total": len(pets),
        "mascotas": pets,
    })


@mascotas_bp.post("")
@token_required
def registrar_mascota():
    """Registra una nueva mascota en la plataforma."""
    data = request.get_json(silent=True) or {}

    nombre = data.get("nombre")
    tipo = data.get("tipo")
    edad = data.get("edad")

    if not nombre or not tipo or edad is None:
        return jsonify({
            "error": "Los campos 'nombre', 'tipo' y 'edad' son obligatorios"
        }), 400

    try:
        pet_id = repository.create_pet(data)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:
        return jsonify({"error": f"Error al registrar la mascota: {str(exc)}"}), 500

    profile = repository.get_pet_profile(pet_id)
    return jsonify({
        "mensaje": "Mascota registrada exitosamente",
        "id": pet_id,
        "mascota": profile["mascota"] if profile else {"id": pet_id, "nombre": nombre},
    }), 201


@mascotas_bp.get("/disponibles")
@token_required
def mascotas_disponibles():
    ciudad = request.args.get("ciudad")
    if not ciudad:
        return jsonify({"error": "El parámetro ciudad es obligatorio"}), 400

    pets = repository.search_available_by_city(ciudad)
    return jsonify({
        "ciudad": ciudad,
        "total": len(pets),
        "mascotas": pets,
    })


@mascotas_bp.get("/filtrar")
@token_required
def mascotas_filtrar():
    tipo = request.args.get("tipo")
    edad_min = request.args.get("edad_min", type=int)
    edad_max = request.args.get("edad_max", type=int)

    if not tipo or edad_min is None or edad_max is None:
        return jsonify({
            "error": "Los parámetros tipo, edad_min y edad_max son obligatorios"
        }), 400

    pets = repository.filter_by_type_and_age(tipo, edad_min, edad_max)
    return jsonify({
        "filtros": {
            "tipo": tipo,
            "edad_min": edad_min,
            "edad_max": edad_max,
        },
        "total": len(pets),
        "mascotas": pets,
    })


@mascotas_bp.post("/compatibles")
@token_required
def mascotas_compatibles():
    data = request.get_json(silent=True) or {}
    has_children = bool(data.get("tiene_ninos", False))
    has_other_pets = bool(data.get("tiene_otras_mascotas", False))
    preferred_size = data.get("tamano_hogar") or data.get("tamano")

    if not preferred_size:
        return jsonify({
            "error": "El campo tamano_hogar es obligatorio (Pequeno, Mediano o Grande)"
        }), 400

    pets = repository.find_compatible_pets(
        has_children,
        has_other_pets,
        preferred_size,
    )
    return jsonify({
        "criterios": {
            "tiene_ninos": has_children,
            "tiene_otras_mascotas": has_other_pets,
            "tamano_hogar": preferred_size,
        },
        "total": len(pets),
        "mascotas": pets,
    })


@mascotas_bp.post("/recomendaciones")
@token_required
def mascotas_recomendaciones():
    data = request.get_json(silent=True) or {}

    preferred_type = data.get("tipo", "")
    preferred_size = data.get("tamano", "")
    min_age = data.get("edad_min", 0)
    max_age = data.get("edad_max", 20)
    accepts_children = bool(data.get("acepta_ninos", False))
    accepts_other_pets = bool(data.get("acepta_otras_mascotas", False))

    pets = repository.recommend_pets(
        preferred_type,
        preferred_size,
        int(min_age),
        int(max_age),
        accepts_children,
        accepts_other_pets,
    )
    return jsonify({
        "preferencias": {
            "tipo": preferred_type,
            "tamano": preferred_size,
            "edad_min": min_age,
            "edad_max": max_age,
            "acepta_ninos": accepts_children,
            "acepta_otras_mascotas": accepts_other_pets,
        },
        "total": len(pets),
        "recomendaciones": pets,
    })


@mascotas_bp.get("/estadisticas")
@token_required
def mascotas_estadisticas():
    stats = repository.get_pet_statistics()
    return jsonify(stats)


@mascotas_bp.get("/<int:mascota_id>/perfil")
@token_required
def mascota_perfil(mascota_id):
    profile = repository.get_pet_profile(mascota_id)
    if not profile:
        return jsonify({"error": f"No existe la mascota con ID {mascota_id}"}), 404
    return jsonify(profile)


@mascotas_bp.get("/<int:mascota_id>")
@token_required
def mascota_detalle(mascota_id):
    profile = repository.get_pet_profile(mascota_id)
    if not profile:
        return jsonify({"error": f"No existe la mascota con ID {mascota_id}"}), 404
    return jsonify(profile["mascota"])
