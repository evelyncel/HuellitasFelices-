import os
from flask import Flask, jsonify, request
from flask_cors import CORS

from config import Config
from utils.auth import authenticate_user, create_token, token_required, hash_password
from utils.database import get_cursor

# Importar Blueprints de los microservicios
from microservicios.mascotas.routes import mascotas_bp
from microservicios.adopciones.routes import adopciones_bp, entrevistas_bp
from microservicios.veterinario.routes import (
    veterinario_mascotas_bp,
    seguimiento_bp,
)

app = Flask(__name__)

# Configuración de CORS permitiendo peticiones desde el frontend (puerto 5174 y otros)
CORS(
    app,
    resources={r"/*": {"origins": "*"}},
    supports_credentials=True,
    allow_headers=["Content-Type", "Authorization", "X-API-KEY", "x-api-key"],
    methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
)


@app.get("/")
def health():
    return jsonify({
        "plataforma": "Huellitas Felices — Plataforma Web de Adopción de Mascotas",
        "servicios": [
            "Gestión y Búsqueda de Mascotas",
            "Gestión de Adopciones",
            "Seguimiento Veterinario",
        ],
        "puerto": Config.SERVER_PORT,
        "estado": "activo",
    })


@app.post("/auth/login")
def login():
    data = request.get_json(silent=True) or {}
    usuario = data.get("usuario")
    password = data.get("password")

    if not usuario or not password:
        return jsonify({"error": "usuario y password son obligatorios"}), 400

    user = authenticate_user(usuario, password)
    if not user:
        return jsonify({"error": "Credenciales inválidas"}), 401

    token = create_token(user)
    return jsonify({
        "mensaje": "Inicio de sesión exitoso",
        "token": token,
        "usuario": {
            "id": user["id"],
            "nombre": user["nombre"],
            "usuario": user["usuario"],
            "rol": user["rol"],
            "ciudad": user.get("ciudad"),
            "experiencia": user.get("experiencia"),
            "tipo_vivienda": user.get("tipo_vivienda"),
        },
    })


@app.post("/auth/register")
def register():
    data = request.get_json(silent=True) or {}
    nombre = (data.get("nombre") or "").strip()
    usuario = (data.get("usuario") or "").strip()
    password = data.get("password") or ""
    ciudad = (data.get("ciudad") or "Popayán").strip()
    edad = int(data.get("edad") or 25)

    if not nombre or not usuario or not password:
        return jsonify({"error": "nombre, usuario y password son obligatorios"}), 400

    try:
        with get_cursor() as cursor:
            cursor.execute("SELECT id FROM usuarios WHERE usuario = %s", (usuario,))
            if cursor.fetchone():
                return jsonify({"error": "El nombre de usuario ya se encuentra registrado"}), 409

            cursor.execute(
                """
                INSERT INTO usuarios (
                    nombre, usuario, password, edad, ciudad, tipo_vivienda,
                    tiene_patio, otras_mascotas, tiempo_disponible, experiencia,
                    preferencia_tipo, preferencia_tamano, preferencia_edad, rol
                )
                VALUES (%s, %s, %s, %s, %s, 'Casa', TRUE, FALSE, 'Medio', 'Amante de las mascotas', 'Todos', 'Mediano', 'Joven', 'adoptante')
                """,
                (nombre, usuario, hash_password(password), edad, ciudad),
            )
            nuevo_id = cursor.lastrowid
            cursor.execute("SELECT id, nombre, usuario, rol, ciudad FROM usuarios WHERE id = %s", (nuevo_id,))
            nuevo_usuario = cursor.fetchone()

        return jsonify({
            "mensaje": "Usuario registrado exitosamente",
            "usuario": nuevo_usuario,
        }), 201
    except Exception as e:
        return jsonify({"error": f"Error al registrar usuario: {str(e)}"}), 500


@app.get("/auth/me")
@token_required
def me():
    """Endpoint para verificar sesión y obtener información del usuario actual."""
    return jsonify({
        "usuario": request.user,
        "valido": True,
    })


# Registrar Blueprints
app.register_blueprint(mascotas_bp)
app.register_blueprint(adopciones_bp)
app.register_blueprint(entrevistas_bp)
app.register_blueprint(veterinario_mascotas_bp)
app.register_blueprint(seguimiento_bp)


if __name__ == "__main__":
    port = Config.SERVER_PORT
    print("==================================================")
    print("  HUELLITAS FELICES — BACKEND UNIFICADO (FLASK)")
    print("==================================================")
    print(f"  Servidor corriendo en: http://localhost:{port}")
    print(f"  Microservicio Mascotas: http://localhost:{port}/api/mascotas")
    print(f"  Microservicio Adopciones: http://localhost:{port}/api/adopciones")
    print(f"  Microservicio Veterinario: http://localhost:{port}/api/seguimiento")
    print("==================================================")
    app.run(
        host=Config.SERVER_HOST,
        port=port,
        debug=True,
    )
